// server.js
require('dotenv').config();
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');

const { bot, setWebhookIfNotSet } = require('./bot');
const { webhookCallback } = require("grammy");

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Webhook do bot (agora na ordem correta!)
app.use("/bot", webhookCallback(bot, "express"));

// Endpoint para pedidos do WebApp
app.post('/api/order', async (req, res) => {
  try {
    const { order, telegram_user } = req.body;
    if (!order || !telegram_user) {
      return res.status(400).json({ error: 'missing order or telegram_user' });
    }

    const chatId = telegram_user.id;
    const summary = order.items
      .map(i => `${i.qty}x ${i.name} — R$ ${i.price}`)
      .join("\n") + `\nTotal: R$ ${order.total}`;

    await bot.api.sendMessage(chatId, `Pedido recebido!\n${summary}`);

    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'internal' });
  }
});

// Start server
app.listen(PORT, async () => {
  console.log(`Server rodando na porta ${PORT}`);
  await setWebhookIfNotSet();
});
